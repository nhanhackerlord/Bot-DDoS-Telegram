bot telegram ddos
this bot gonna run the command in your device and start the ddos by using node js file
if you want to improve power just use botslave.py in another device
